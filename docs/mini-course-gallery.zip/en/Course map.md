# Reconcile a weekly report

For someone who compares orders with payments by hand. By the end you can identify an underpaid order even when the lists are sorted differently.

1. Try [[Match the orders]].
2. Open [[Answer key]].
3. Add your own example with [[Lesson template]].

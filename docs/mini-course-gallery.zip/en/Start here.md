# Build a mini-course in Obsidian

Start with the [[Course map]]. Try the exercise before opening the answer. Duplicate [[Lesson template]] to teach a skill of your own.

[Explore the full Vaultforge product (in Russian)](https://vaultforge.ru/?src=gallery-demo#inside)

# Which order was underpaid?

Order amounts: A 1200, B 900, C 700.

Payments received: C 700, A 1200, B 600.

Match each payment to its order by letter. Subtract the payment from the order amount. Write down the letter and outstanding balance, then open [[Answer key]].

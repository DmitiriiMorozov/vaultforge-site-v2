# Give the lesson a name

## Outcome
What can a learner do at the end?

## Starting material
Give the learner a small, realistic input.

## Exercise
Describe what to produce using that input.

## Check your work
Give an expected answer and explain one likely mistake.

[[Course map]]

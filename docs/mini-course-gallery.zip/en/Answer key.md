# Check your reconciliation

Order B has an outstanding balance of 300 (900 − 600). A and C are fully paid. If several balances look wrong, check the order letters: the payment list is sorted differently.

[[Course map]]
